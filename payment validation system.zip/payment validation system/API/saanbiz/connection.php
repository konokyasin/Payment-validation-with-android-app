<?php

define('hostname', 'localhost');
define('user', 'root');
define('password', '');
define('databaseName', 'saanbiz_app');

$connect = mysqli_connect(hostname, user, password, databaseName)or die("DB Connection Error");;
//echo "DONE";


?>