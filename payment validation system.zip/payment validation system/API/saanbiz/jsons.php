<?php

include "connection.php";

$transArray = array();

if(isset($_POST["transections"])){
    
    $id = $_POST["user_id"];

    $query = "SELECT * FROM `transections` WHERE `user_id` = $id";
        
    $result = mysqli_query($connect, $query);
    
    while($row = mysqli_fetch_assoc($result)) {
        $json['inv_id']=  $row['id'];
        $json['trn_id']=  $row['trx_id'];
        $json['trn_by']=  $row['trx_by'];
        $json['trn_from']=  $row['trx_from'];
        $json['amount']=  $row['amount'];
        $json['date']=  $row['date'];
        
        array_push($transArray,$json);
    }
	
    $j['transections'] =$transArray;
    echo json_encode($j);
	
    mysqli_close($connect);
}

?>