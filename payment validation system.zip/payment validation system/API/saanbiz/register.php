<?php

include "connection.php";

$response = array("success" => FALSE);

if(isset($_POST["name"])){
    
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $pass = $_POST["pass"];
   

    $query = "INSERT INTO `user`(`name`, `email`, `phone`, `password`) VALUES ('$name','$email','$phone','$pass')";
    $result = mysqli_query($connect, $query);
    
    if($result)
    {
        $response["success"] = TRUE;
        echo json_encode($response);
    }
    else
    {
        $response["success"] = FALSE;
        echo json_encode($response);
    }
        
    mysqli_close($connect);
    
}
?>