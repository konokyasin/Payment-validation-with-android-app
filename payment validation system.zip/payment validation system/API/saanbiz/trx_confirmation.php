<?php

include "connection.php";

$response = array("success" => FALSE);

if(isset($_POST["user_id"])){
    
    $user_id = $_POST["user_id"];
    $trx_id = $_POST["trx_id"];
	$trx_by = $_POST["trx_by"];

	
    
	$query ="SELECT `id`, `trx_id`, `trx_from`, `trx_by`, `amount`, `current_balance`, `date` FROM `pending_trxs` WHERE `trx_id` = '$trx_id'";
    $result = mysqli_query($connect, $query);
	
	$rows =  mysqli_fetch_array($result);
	$from_db_trx_id = $rows['trx_id'];
	$from_db_trx_by = $rows['trx_by'];
	if($from_db_trx_id == $trx_id && $trx_by == $from_db_trx_by ){
		$trx_from = $rows['trx_from'];
		$amount = $rows['amount'];
		$date = $rows['date'];
		
		$query = "INSERT INTO `transections`( `user_id`, `trx_id`, `trx_from`, `trx_by`, `amount`, `date`) VALUES ('$user_id','$trx_id','$trx_from','$trx_by','$amount','$date')";
		$result = mysqli_query($connect, $query);
		if($result){
			$response["success"] = TRUE;
			echo json_encode($response);
			$query = "DELETE FROM `pending_trxs` WHERE `trx_id` = '$trx_id'";
			$result = mysqli_query($connect, $query);
			
		}else{
			$response["success"] = FALSE;
			echo json_encode($response);
		}
		
	}else{
		$response["success"] = FALSE;
		echo json_encode($response);
	}
        
    mysqli_close($connect);
    
}
?>