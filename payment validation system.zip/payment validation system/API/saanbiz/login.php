<?php
include "connection.php";

$json = array("success" => FALSE);
if(isset($_POST["email"])){
    
    $email = $_POST["email"];
    $pass = $_POST["pass"];
    
    $query = "SELECT `id`, `name`, `email`, `phone`, `password`, `is_verified` FROM `user` WHERE email = '$email';";        
    $result = mysqli_query($connect, $query);
    $rows =  mysqli_fetch_array($result);
	
    $from_db_pass = $rows['password'];
	
    if($pass == $from_db_pass){
        $json['success'] = TRUE;
		
		$json['user']['id'] = $rows['id'];
        $json['user']['name'] = $rows['name'];
        $json['user']['email'] = $email;
		$json['user']['phone'] = $rows['phone'];
		if($rows['is_verified'] == 1)
			$json['user']['is_verified'] = TRUE;
		else
			$json['user']['is_verified'] = FALSE;
     
        echo json_encode($json);
        //echo "success";
    }else{
        $json['success'] = FALSE;
        echo json_encode($json);
    }
    mysqli_close($connect);
}
?>