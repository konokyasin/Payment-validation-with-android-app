<?php

include "connection.php";

$response = array("error" => FALSE);

if(isset($_POST["trx_id"])){
    
    $trx_id = $_POST["trx_id"];
    $trx_from = $_POST["trx_from"];
    $trx_by = $_POST["trx_by"];
    $amount = $_POST["amount"];
    $current_balance = $_POST["current_balance"];

    //remove commas from numeric strings
	//if(preg_match("/^[0-9,]+$/", $amount)) 
		$amount = str_replace(',', '', $amount);
	//if(preg_match("/^[0-9,]+$/", $current_balance)) 
		$current_balance = str_replace(',', '', $current_balance);

    $query = "INSERT INTO `pending_trxs`(`trx_id`, `trx_from`, `trx_by`, `amount`, `current_balance`, `date`) VALUES ('$trx_id', '$trx_from', '$trx_by','$amount', '$current_balance', CURDATE());";
        
        
    $result = mysqli_query($connect, $query);
    
    if($result)
    {
        $response["error"] = TRUE;
        echo json_encode($response);
    }
    else
    {
        $response["error"] = FALSE;
        echo json_encode($response);
    }
        
    mysqli_close($connect);
    
}
?>