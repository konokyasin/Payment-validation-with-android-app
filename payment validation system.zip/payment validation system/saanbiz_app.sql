-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 30, 2019 at 02:20 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saanbiz_app`
--

-- --------------------------------------------------------

--
-- Table structure for table `pending_trxs`
--

CREATE TABLE `pending_trxs` (
  `id` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `trx_from` varchar(255) NOT NULL,
  `trx_by` varchar(255) NOT NULL,
  `amount` int(20) NOT NULL,
  `current_balance` int(25) NOT NULL,
  `date` varchar(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `transections`
--

CREATE TABLE `transections` (
  `id` int(20) NOT NULL,
  `user_id` int(50) NOT NULL,
  `trx_id` varchar(150) NOT NULL,
  `trx_from` varchar(50) NOT NULL,
  `trx_by` varchar(20) NOT NULL,
  `amount` int(20) NOT NULL,
  `date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transections`
--

INSERT INTO `transections` (`id`, `user_id`, `trx_id`, `trx_from`, `trx_by`, `amount`, `date`) VALUES
(1, 11, 'AAAff22gstT', '016715555454', 'bKash', 11, '10.10.2018'),
(2, 15, 'AAAff22gstTa', '4545488', 'rocket', 11, '11.10.2018'),
(3, 15, '1263564', '05105', 'bKash', 100, '10.12.2018'),
(6, 16, '4KC2PTJUTK', '01987000366', 'bKash', 10, '2019-01-11'),
(7, 16, 'RxI12', '01671352227', 'bKash', 1545, '2019-01-11'),
(8, 16, '123', ' 01671352227 ', 'bKash', 100, '2019-01-11'),
(9, 17, '4KC2P09TJK', '01987000366', 'bKash', 10, '2019-01-12');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(20) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(150) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_verified` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `phone`, `password`, `is_verified`) VALUES
(11, 'Mahdi Ha', 'sssssssssssssssssss', 'ssssssssssssssssssss', 'sssssssssssssssss', 0),
(15, 'Zahdi Ha', 'sfssff', '', 'sfssff', 1),
(16, 'Maidul I', 'user', '0167545', 'user', 0),
(17, 'Check ', 'Check', '', 'check', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pending_trxs`
--
ALTER TABLE `pending_trxs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `trx_id` (`trx_id`);

--
-- Indexes for table `transections`
--
ALTER TABLE `transections`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `trx_id` (`trx_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pending_trxs`
--
ALTER TABLE `pending_trxs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `transections`
--
ALTER TABLE `transections`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `transections`
--
ALTER TABLE `transections`
  ADD CONSTRAINT `transections_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
