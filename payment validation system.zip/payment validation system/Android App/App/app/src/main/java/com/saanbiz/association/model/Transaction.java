package com.saanbiz.association.model;

public class Transaction {
    private int inv_id;
    private String trn_id;
    private String trn_by;
    private String trn_from;
    private int amount;
    private String date_time;


    public Transaction(int inv_id, String trn_id, String trn_by, String trn_from, int amount, String date_time) {
        this.inv_id = inv_id;
        this.trn_id = trn_id;
        this.trn_by = trn_by;
        this.trn_from = trn_from;
        this.amount = amount;
        this.date_time = date_time;
    }

    public int getInv_id() {
        return inv_id;
    }

    public String getTrn_id() {
        return trn_id;
    }

    public String getTrn_by() {
        return trn_by;
    }

    public String getTrn_from() {
        return trn_from;
    }

    public int getAmount() {
        return amount;
    }

    public String getDate_time() {
        return date_time;
    }


}
