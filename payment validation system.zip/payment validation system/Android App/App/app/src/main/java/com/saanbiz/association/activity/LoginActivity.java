package com.saanbiz.association.activity;

import  android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.saanbiz.association.R;
import com.saanbiz.association.request.LoginRequest;

import org.json.JSONException;
import org.json.JSONObject;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    EditText editText_email, editText_pass;
    Button btn_login, btn_go_signup, btn_forgot_pass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btn_login = findViewById(R.id.login_button);
        btn_go_signup = findViewById(R.id.login_sign_up);
        btn_forgot_pass = findViewById(R.id.login_forget);

        editText_email = findViewById(R.id.login_email);
        editText_pass = findViewById(R.id.login_pass);

        btn_login.setOnClickListener(this);
        btn_go_signup.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.login_button) {
            goLogin();
        }else if(v.getId() == R.id.login_sign_up){
            Intent intent = new Intent(LoginActivity.this, SignUpActivity.class);
            startActivity(intent);
        }

    }

    private void goLogin() {
        final String email = editText_email.getText().toString();
        final String pass = editText_pass.getText().toString();

        Response.Listener<String> responseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");
                    if (success) {
                        JSONObject user = jsonResponse.getJSONObject("user");

                        int id = user.getInt("id");
                        String name = user.getString("name");
                        String email = user.getString("email");
                        String phone = user.getString("phone");
                        Boolean is_verified = user.getBoolean("is_verified");

                        SharedPreferences sharedpreferences = getApplicationContext().getSharedPreferences("LogIn_Preferences", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedpreferences.edit();
                        editor.putInt("id", id);
                        editor.putString("name", name);
                        editor.putString("email", email);
                        editor.putString("phone", phone);
                        editor.putBoolean("is_verified", is_verified);
                        editor.putBoolean("is_LoggedIn",true);
                        editor.commit();

                        onLoginSuccess();

                    } else {
                        Toast.makeText(LoginActivity.this, "Something went wrong !!!", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        };

        LoginRequest loginRequest = new LoginRequest(email, pass, responseListener);
        RequestQueue queue = Volley.newRequestQueue(LoginActivity.this);
        queue.add(loginRequest);

    }

    public void onLoginSuccess() {
        btn_login.setEnabled(true);
        Toast.makeText(getBaseContext(), "Login Successfully", Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(LoginActivity.this, ProfileActivity.class);
        startActivity(intent);
        finish();
    }
}
