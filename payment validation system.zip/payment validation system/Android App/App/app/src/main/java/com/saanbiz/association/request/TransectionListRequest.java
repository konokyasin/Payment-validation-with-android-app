package com.saanbiz.association.request;


import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.saanbiz.association.config.Config;

import java.util.HashMap;
import java.util.Map;

public class TransectionListRequest extends StringRequest {

    private static final String UTILS_URL = Config.getUtils();
    private Map<String,String> params;

    public TransectionListRequest(String transections,String user_id,Response.Listener<String> listener) {
        super(Method.POST, UTILS_URL, listener, null);
        params = new HashMap<>();
        params.put("transections",transections);
        params.put("user_id",user_id);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
