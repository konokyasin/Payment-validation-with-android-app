package com.saanbiz.association.adupter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.saanbiz.association.R;
import com.saanbiz.association.model.Transaction;

import java.util.List;

public class TransactionsAdapter extends ArrayAdapter<Transaction> {
    private List<Transaction> transactionList;
    private Context context;

    public TransactionsAdapter(Context context, List<Transaction> transactionList) {
        super(context, R.layout.activity_transaction_list_view,transactionList);
        this.transactionList = transactionList;
        this.context = context;
    }

    public View getView(int position,  View convertView,  ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.activity_transaction_list_view,null,true);

        TextView trn_by = view.findViewById(R.id.text_trnx_by);
        TextView trn_from = view.findViewById(R.id.text_trnx_from);
        TextView trn_id = view.findViewById(R.id.text_trnx_id);
        TextView inv_id = view.findViewById(R.id.text_trnx_ivoice_id);
        TextView trn_amount = view.findViewById(R.id.text_trnx_amount);
        TextView trn_date_time = view.findViewById(R.id.text_trnx_date_time);

        Transaction transaction = transactionList.get(position);
        trn_by.setText("Transaction by "+transaction.getTrn_by());
        trn_from.setText("From: "+transaction.getTrn_from());
        trn_id.setText("TrxID: "+transaction.getTrn_id());
        inv_id.setText("Invoice ID: "+transaction.getInv_id());
        trn_amount.setText(""+transaction.getAmount());
        trn_date_time.setText(""+transaction.getDate_time());

        return view;
    }
}
