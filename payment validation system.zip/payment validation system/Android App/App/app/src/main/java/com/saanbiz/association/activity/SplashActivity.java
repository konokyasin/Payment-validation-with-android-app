package com.saanbiz.association.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.saanbiz.association.R;

public class SplashActivity extends AppCompatActivity {
    ImageView icon , logo;
    private SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_splash);

        icon = findViewById(R.id.splash_imageView_icon);
        logo = findViewById(R.id.splash_imageView_logo);

        Animation anim_frrom_top = AnimationUtils.loadAnimation(this, R.anim.from_top);
        Animation anim_frrom_bttm = AnimationUtils.loadAnimation(this, R.anim.from_bottom);
        icon.setAnimation(anim_frrom_top);
        logo.setAnimation(anim_frrom_bttm);

        sharedPreferences = getApplicationContext().getSharedPreferences("LogIn_Preferences",MODE_PRIVATE);
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if(sharedPreferences.getBoolean("is_LoggedIn", false)){
                    Intent intent = new Intent(SplashActivity.this,ProfileActivity.class);
                    startActivity(intent);
                    finish();
                }else{
                    Intent intent = new Intent(SplashActivity.this,LoginActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        },4000);


    }
}
