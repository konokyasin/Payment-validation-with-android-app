package com.saanbiz.association.activity;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.saanbiz.association.R;
import com.saanbiz.association.adupter.TransactionsAdapter;
import com.saanbiz.association.model.Transaction;
import com.saanbiz.association.request.TransectionListRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class TransactionHistoryActivity extends AppCompatActivity {
    private ListView listView_transection;
    List<Transaction> transactionList;

    private SharedPreferences sharedPreferences;
    private int id;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction_history);


        sharedPreferences = getSharedPreferences("LogIn_Preferences",MODE_PRIVATE);
        id = sharedPreferences.getInt("id",0);
        setTransactionListData("Yes",id);

    }

    private void setTransactionListData(String transections, int user_id ){

        listView_transection = findViewById(R.id.listView_transections);
        transactionList = new ArrayList<>();

        Response.Listener<String> stringListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("transections");
                    for(int i = 0 ; i <jsonArray.length() ; i++){
                        JSONObject o = jsonArray.getJSONObject(i);
                        Log.i("jason",o.toString());
                        transactionList.add(new Transaction(Integer.parseInt(o.getString("inv_id")),
                                o.getString("trn_id"),o.getString("trn_by"),o.getString("trn_from"),
                                Integer.parseInt(o.getString("amount")),o.getString("date")));

                    }
                    TransactionsAdapter transactionsAdapter = new TransactionsAdapter(TransactionHistoryActivity.this, transactionList);
                    listView_transection.setAdapter(transactionsAdapter);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

        TransectionListRequest transectionListRequest = new TransectionListRequest(transections,Integer.toString(user_id),stringListener);
        RequestQueue queue = Volley.newRequestQueue(TransactionHistoryActivity.this);
        queue.add(transectionListRequest);
    }
}
