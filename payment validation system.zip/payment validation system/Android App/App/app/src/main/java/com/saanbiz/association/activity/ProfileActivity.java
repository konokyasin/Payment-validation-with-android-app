package com.saanbiz.association.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.saanbiz.association.R;
import com.saanbiz.association.adupter.TransactionsAdapter;
import com.saanbiz.association.model.Transaction;
import com.saanbiz.association.request.TransectionListRequest;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ProfileActivity extends AppCompatActivity implements View.OnClickListener {
    TextView profile_name,total_deposit,pending_deposit;
    ImageView btn_deposit , btn_history, btn_help , manu_icon;


    private SharedPreferences sharedPreferences;
    private String name;
    private int id;
    private boolean is_verified;
    private int totalDeposit = 0;
    private String lastDateofDeposit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        profile_name = findViewById(R.id.profile_name);
        total_deposit = findViewById(R.id.text_total_deposit);
        pending_deposit = findViewById(R.id.text_total_pending);

        sharedPreferences = getSharedPreferences("LogIn_Preferences",MODE_PRIVATE);
        id = sharedPreferences.getInt("id",0);
        name = sharedPreferences.getString("name","");
        is_verified = sharedPreferences.getBoolean("is_verified",false);

        profile_name.setText(name);
        setTotalDeposit(id);

        btn_deposit = findViewById(R.id.profile_btn_deposit);
        btn_history = findViewById(R.id.profile_btn_history);
        manu_icon = findViewById(R.id.manu_icon);
        btn_deposit.setOnClickListener(this);
        btn_history.setOnClickListener(this);
        manu_icon.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.profile_btn_deposit){
            //diposit button clicked
            Intent intent = new Intent(ProfileActivity.this,PaymentActivity.class);
            startActivity(intent);
        }

        else if(v.getId() == R.id.profile_btn_history){
            //history button clicked
            Intent intent = new Intent(ProfileActivity.this,TransactionHistoryActivity.class);
            startActivity(intent);
        }
        else if(v.getId() == R.id.manu_icon){
            //Testting Log out
            sharedPreferences.edit().clear().commit();
            Intent intent = new Intent(ProfileActivity.this,LoginActivity.class);
            startActivity(intent);
        }

    }

    private void setTotalDeposit(int user_id){

        Response.Listener<String> stringListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonObject = new JSONObject(response);
                    JSONArray jsonArray = jsonObject.getJSONArray("transections");
                    for(int i = 0 ; i <jsonArray.length() ; i++){
                        JSONObject o = jsonArray.getJSONObject(i);
                        Log.i("jason",o.toString());
                        totalDeposit = totalDeposit + Integer.parseInt(o.getString("amount"));
                        lastDateofDeposit = o.getString("date");
                    }

                    total_deposit.setText(Integer.toString(totalDeposit)+" TK");

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        };

        TransectionListRequest transectionListRequest = new TransectionListRequest("Yes",Integer.toString(user_id),stringListener);
        RequestQueue queue = Volley.newRequestQueue(ProfileActivity.this);
        queue.add(transectionListRequest);
    }

}
