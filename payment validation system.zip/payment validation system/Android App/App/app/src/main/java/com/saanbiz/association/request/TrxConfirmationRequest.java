package com.saanbiz.association.request;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;
import com.saanbiz.association.config.Config;

import java.util.HashMap;
import java.util.Map;

public class TrxConfirmationRequest extends StringRequest{
    private static final String TRX_CONFIRM_URL = Config.getTrx_confirmation();
    private Map<String,String> params;

    public TrxConfirmationRequest(String user_id,String trx_id,String trx_by,Response.Listener<String> listener) {
        super(Request.Method.POST, TRX_CONFIRM_URL, listener, null);
        params = new HashMap<>();
        params.put("user_id",user_id);
        params.put("trx_id",trx_id);
        params.put("trx_by",trx_by);
    }

    @Override
    public Map<String, String> getParams() {
        return params;
    }
}
