package com.saanbiz.association.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.saanbiz.association.R;
import com.saanbiz.association.request.TrxConfirmationRequest;

import org.json.JSONException;
import org.json.JSONObject;

public class PaymentActivity extends AppCompatActivity implements View.OnClickListener {
    private Boolean bkash_is_clicked = true , rocket_is_clicked = false;
    ImageView btn_bkash , btn_rocket , btn_confirm;
    EditText input_Trx_id;
    TextView wallet,amount_to_pay,quicktip,quicktip_text;
    private SharedPreferences sharedPreferences;
    private int id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        btn_bkash = findViewById(R.id.btn_bkash);
        btn_rocket = findViewById(R.id.btn_rocket);
        btn_confirm = findViewById(R.id.btn_confirm);

        input_Trx_id = findViewById(R.id.input_Trx_id);

        wallet = findViewById(R.id.wallet);
        amount_to_pay = findViewById(R.id.amount_to_pay);
        quicktip = findViewById(R.id.quicktip);
        quicktip_text = findViewById(R.id.quicktip_text);

        sharedPreferences = getSharedPreferences("LogIn_Preferences",MODE_PRIVATE);
        id = sharedPreferences.getInt("id",0);


        btn_bkash.setOnClickListener(this);
        btn_rocket.setOnClickListener(this);
        btn_confirm.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.btn_bkash){
            bkash_is_clicked = true;
            rocket_is_clicked = false;
            btn_rocket.setImageResource(R.drawable.rocket_bw);
            btn_bkash.setImageResource(R.drawable.bkash_color);
            showBkashDetails();
        }

        if(v.getId() == R.id.btn_rocket){
            bkash_is_clicked = false;
            rocket_is_clicked = true;
            btn_rocket.setImageResource(R.drawable.rocket_color);
            btn_bkash.setImageResource(R.drawable.bkash_bw);
            showRocketDetails();
        }

        if(v.getId() == R.id.btn_confirm){
            if(bkash_is_clicked){
                bKashTransection(Integer.toString(id),input_Trx_id.getText().toString(),"bKash");
                //Toast.makeText(PaymentActivity.this, input_Trx_id.getText(), Toast.LENGTH_SHORT).show();

            }else if(rocket_is_clicked){
                Toast.makeText(this,"Rocked id clicked ",Toast.LENGTH_SHORT).show();
            }else {
                Toast.makeText(this,"Nothing was selected !",Toast.LENGTH_SHORT).show();
            }

        }

    }

    private void showBkashDetails(){
        btn_confirm.setVisibility(View.VISIBLE);
        wallet.setText("bKash Wallet: 01830498156");
        amount_to_pay.setText("Amount: As you want");
        quicktip.setText("Quick Tip");
        quicktip_text.setText(" Use Option 2 on the bKash menu.");
    }

    private void showRocketDetails(){
        wallet.setText("Sorry :)");
        amount_to_pay.setText("  ROCKET Not Available Right Now");
        quicktip.setText(" ");
        quicktip_text.setText(" ");
        btn_confirm.setVisibility(View.INVISIBLE);
    }

    private void bKashTransection(String user_id,String trx_id,String trx_by){

        Response.Listener<String> responseListener = new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    boolean success = jsonResponse.getBoolean("success");
                    if (success) {
                        Toast.makeText(getBaseContext(), "Payment Successful!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(PaymentActivity.this, ProfileActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(PaymentActivity.this, "Something went wrong !!!", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {

                    e.printStackTrace();
                }
            }
        };

        TrxConfirmationRequest trxConfirmationRequest = new TrxConfirmationRequest(user_id,trx_id,trx_by,responseListener);
        RequestQueue queue = Volley.newRequestQueue(PaymentActivity.this);
        queue.add(trxConfirmationRequest);
    }
}
