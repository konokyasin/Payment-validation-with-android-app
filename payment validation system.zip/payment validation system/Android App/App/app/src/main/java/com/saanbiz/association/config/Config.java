package com.saanbiz.association.config;

public class Config {
    private static String ip = "192.168.0.101";
    //private static String ip = "127.0.0.1";

    private static String register = "http://"+ip+"/saanbiz/register.php";
    private static String login = "http://"+ip+"/saanbiz/login.php";
    private static String utils = "http://"+ip+"/saanbiz/jsons.php";
    private static String trx_confirmation = "http://"+ip+"/saanbiz/trx_confirmation.php";


    public static String getRegister() {
        return register;
    }

    public static String getLogin() {
        return login;
    }

    public static String getUtils() {
        return utils;
    }

    public static String getTrx_confirmation() {
        return trx_confirmation;
    }
}
